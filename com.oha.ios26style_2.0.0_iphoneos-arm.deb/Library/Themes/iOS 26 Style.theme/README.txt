iOS 26 Style for iOS 7 — v2
- Original glass-style icons
- Original glass Control Center artwork
- Lightweight PNG assets designed for legacy devices
- No Apple copyrighted artwork is bundled
