Original glass Control Center artwork for the iOS 26 Style theme. Exact iOS 7 Control Center hook names vary by legacy tweak/WinterBoard implementation.
