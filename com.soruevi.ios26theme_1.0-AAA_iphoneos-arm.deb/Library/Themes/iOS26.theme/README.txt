iOS 26 Theme - AAA Quality - Liquid Glass
By Soruevi.az

Features:
- Liquid Glass icons (iOS 26 style)
- iOS 26 wallpaper (purple/blue glass orbs)
- Liquid Glass dock
- iOS 26 status bar
- Works on iPhone 4 iOS 7.1.2 with WinterBoard/Anemone

Install:
1. Install this theme from Cydia
2. Open WinterBoard or Anemone
3. Select iOS 26 - AAA Liquid Glass
4. Apply and Respring

Enjoy iOS 26 on iPhone 4!
