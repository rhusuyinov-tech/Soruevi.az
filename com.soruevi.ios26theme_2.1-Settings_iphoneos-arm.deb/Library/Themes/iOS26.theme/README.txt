iOS 26 Theme 2.1 - Settings ici de deyisir!
- Wallpaper iOS 26 Liquid Glass
- Iconlar Liquid Glass
- Settings background dark glass
- Table cells translucent
- WinterBoard ile aktiv et
